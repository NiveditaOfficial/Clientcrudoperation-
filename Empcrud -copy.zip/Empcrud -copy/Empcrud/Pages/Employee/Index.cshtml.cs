using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Empcrud.Pages.Employee
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
        public void OnPost() {


        }
    }
}
